package com.sgg.schedule.servlet.impl;

import com.sgg.schedule.servlet.SysScheduleService;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 李阳
 * @Date: 2024/12/30/15:37
 * @Description:
 */
public class SysScheduleServletImpl implements SysScheduleService {

}

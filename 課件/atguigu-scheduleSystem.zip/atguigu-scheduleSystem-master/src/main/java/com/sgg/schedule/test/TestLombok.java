package com.sgg.schedule.test;

import com.sgg.schedule.pojo.SysUser;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 李阳
 * @Date: 2024/12/30/10:57
 * @Description:
 */
public class TestLombok {
    public void test() {
        SysUser sysUser = new SysUser();


    }

}

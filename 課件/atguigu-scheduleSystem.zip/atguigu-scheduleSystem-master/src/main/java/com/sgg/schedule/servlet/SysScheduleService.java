package com.sgg.schedule.servlet;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: 李阳
 * @Date: 2024/12/30/15:37
 * @Description:
 */
public interface SysScheduleService {
}
